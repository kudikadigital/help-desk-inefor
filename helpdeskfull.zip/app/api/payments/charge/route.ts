import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import {
  buildConfig,
  createCharge,
  getMethodId,
  generateMerchantTransactionId,
  type PaymentMethod,
} from '@/lib/appypay'
import {
  sendPaymentConfirmationEmail,
} from '@/lib/brevo'

const COMPANY_NAME = process.env.PAYMENT_COMPANY_NAME || 'INEFOR'
const NOTIFY_EMAIL = process.env.NOTIFY_EMAIL || 'geral@inefor.ao'
const COURSE_NAME = 'Help Desk — Formação Prática'

interface ChargeRequest {
  batchId: string
  batchName: string
  amount: number
  method: PaymentMethod
  fullName: string
  email: string
  phone: string
  phoneNumber?: string // para GPO
}

export async function POST(request: NextRequest) {
  try {
    const body: ChargeRequest = await request.json()
    const { batchId, batchName, amount, method, fullName, email, phone, phoneNumber } = body

    if (!batchId || !batchName || !amount || !method || !fullName || !email || !phone) {
      return NextResponse.json({ error: 'Dados incompletos.' }, { status: 400 })
    }

    if (method === 'GPO' && !phoneNumber) {
      return NextResponse.json(
        { error: 'Número Multicaixa Express obrigatório para pagamento GPO.' },
        { status: 400 }
      )
    }

    const config = buildConfig()
    const merchantTransactionId = generateMerchantTransactionId()
    const methodId = getMethodId(config, method)

    // Chamar AppyPay
    const appypayResponse = await createCharge(config, {
      merchantTransactionId,
      amount,
      currency: 'AOA',
      paymentMethod: methodId,
      customerName: fullName,
      customerEmail: email,
      customerPhone: phone,
      description: `${COURSE_NAME} — ${batchName}`,
      ...(method === 'GPO' && { phoneNumber }),
    })

    console.log('AppyPay response:', JSON.stringify(appypayResponse, null, 2))

    const { responseStatus } = appypayResponse
    const isGPO = method === 'GPO'

    // Determinar status
    let status: 'pending' | 'paid' | 'failed' = 'pending'
    if (isGPO) {
      status = responseStatus.successful && responseStatus.status === 'Success' ? 'paid' : 'failed'
    }

    // Guardar pagamento no Prisma
    await prisma.payment.create({
      data: {
        batchId,
        batchName,
        amount,
        currency: 'AOA',
        paymentMethod: method,
        appypayChargeId: appypayResponse.id,
        merchantTransactionId,
        status,
        phoneNumber: phoneNumber || phone,
        referenceNumber: responseStatus.reference?.referenceNumber,
        referenceEntity: responseStatus.reference?.entity,
        fullName,
        email,
        phone,
        expiresAt: responseStatus.reference?.dueDate
          ? new Date(responseStatus.reference.dueDate)
          : null,
        paidAt: status === 'paid' ? new Date() : null,
      },
    })

    // Actualizar lead para AGUARDANDO_VALIDACAO (ou MATRICULADO se GPO pago)
    await prisma.lead.upsert({
      where: { email },
      update: {
        name: fullName,
        phone,
        status: status === 'paid' ? 'MATRICULADO' : 'AGUARDANDO_VALIDACAO',
      },
      create: {
        name: fullName,
        email,
        phone,
        status: status === 'paid' ? 'MATRICULADO' : 'AGUARDANDO_VALIDACAO',
      },
    })

    // GPO falhou
    if (isGPO && status === 'failed') {
      return NextResponse.json({
        success: false,
        method,
        error: responseStatus.message || 'Pagamento recusado. Verifique o saldo ou tente novamente.',
      })
    }

    // Enviar emails via Brevo
    const brevoApiKey = process.env.BREVO_API_KEY
    if (brevoApiKey) {
      await sendPaymentConfirmationEmail(brevoApiKey, {
        email,
        fullName,
        courseName: `${COURSE_NAME} — ${batchName}`,
        amount,
        method,
        referenceNumber: responseStatus.reference?.referenceNumber,
        referenceEntity: responseStatus.reference?.entity,
        referenceExpiry: responseStatus.reference?.dueDate,
        companyName: COMPANY_NAME,
        notifyEmail: NOTIFY_EMAIL,
      }).catch((e) => console.error('Brevo email error:', e))
    }

    return NextResponse.json({
      success: true,
      method,
      ...(isGPO && { gpoStatus: 'paid' }),
      ...(!isGPO && {
        referenceNumber: responseStatus.reference?.referenceNumber,
        referenceEntity: responseStatus.reference?.entity,
        referenceExpiry: responseStatus.reference?.dueDate,
      }),
    })
  } catch (error) {
    console.error('Payment charge error:', error)
    return NextResponse.json({ error: 'Erro interno ao processar pagamento.' }, { status: 500 })
  }
}
